class CreateTickets < ActiveRecord::Migration[5.1]
  def change
    create_table :tickets do |t|
      t.string :plate
      t.datetime :time_in
      t.datetime :time_out
      t.string  :v_type
      t.timestamps
    end
  end
end
