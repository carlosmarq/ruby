class CreateWorkshifts < ActiveRecord::Migration[5.1]
  def change
    create_table :workshifts do |t|
      t.string :user
      t.datetime :time_arrive
      t.datetime :time_leave

      t.timestamps
    end
  end
end
