class Workshift < ApplicationRecord
end
