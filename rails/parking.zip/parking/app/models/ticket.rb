class Ticket < ApplicationRecord
  validates :plate,  format: { with: /[A-Z]{3}[0-9]{3}/ }
end
