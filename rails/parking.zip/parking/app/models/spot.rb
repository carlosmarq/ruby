class Spot < ApplicationRecord
end
