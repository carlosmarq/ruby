class TicketsController < ApplicationController

  def new
    @ticket=Ticket.new()
  end

  def show
    @ticket = Ticket.find(params[:id])
  end

  def edit
    @ticket = Ticket.find(params[:id])
  end

  def create
    @ticket = Ticket.new
    @ticket.plate = ticket_params[:plate]
    @ticket.v_type = ticket_params[:v_type]
    @ticket.time_in = DateTime.now

    if @ticket.save
      redirect_to ticket_path(@ticket)
    else
      render 'new'
    end
  end

  def destroy
  end

  def bill
    @ticket = Ticket.find(params[:id])
    if !@ticket.time_out.blank?
      redirect_to ticket_path(@ticket)
    else
      @ticket.time_out = DateTime.now
      @ticket.save
    end


    if @ticket.v_type == "Car"
      @price = 90
    elsif
      @ticket.v_type == "Bike"
      @price = 10
    elsif
      @ticket.v_type == "Moto"
      @price = 60
    end

      @time = @ticket.time_out - @ticket.time_in
      @time = @time/60

      @payment = @time * @price
  end


  def index
    @ticket = Ticket.all
  end

  def monitor
    @ticket = Ticket.all
  end

  def update
    @ticket =Ticket.find(params[:id])

    if @ticket.update(ticket_params)
    redirect_to ticket_path(@ticket)
    else
    render 'edit'
    end
  end


  private

 def ticket_params
   params.require(:ticket).permit(:plate,:v_type)
 end

end
