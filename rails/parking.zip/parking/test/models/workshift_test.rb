require 'test_helper'

class WorkshiftTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
